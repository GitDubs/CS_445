
package videoengine;

/**
 * A film in the video engine.
 */
public interface Film extends Video {

}

