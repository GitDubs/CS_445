//Ben Aston 
//CS 445, Monday/Wednesday night lecture
//Professor Garrision
//Date last updated: 2/21/2016
//Assignment 2, IllegalOperatorException

public class IllegalOperatorException extends Exception{
    public IllegalOperatorException(){
        super("Illegal Operator");
    }
}
